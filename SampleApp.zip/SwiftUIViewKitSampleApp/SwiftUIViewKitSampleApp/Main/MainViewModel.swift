//
//  MainViewModel.swift
//  SwiftUIViewKitSampleApp
//
//  Created by LONELiE on 2023/02/10.
//

import Foundation

struct MainViewModel {
    var userText: String = "noting..."
    var clickedCount: Int = 0
}
